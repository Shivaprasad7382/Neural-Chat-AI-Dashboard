import { useState, useEffect, useRef, useCallback } from 'react'
import './App.css'

const API = ''

const PERSONAS = [
  { id: 'default', label: 'Assistant', icon: '◈', color: '#7c6af7' },
  { id: 'creative', label: 'Creative', icon: '✦', color: '#f472b6' },
  { id: 'analyst', label: 'Analyst', icon: '◉', color: '#38bdf8' },
  { id: 'mentor', label: 'Mentor', icon: '◎', color: '#4ade80' },
]

function formatTime(ts) {
  return new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
}

function formatUptime(secs) {
  const h = Math.floor(secs / 3600)
  const m = Math.floor((secs % 3600) / 60)
  return `${h}h ${m}m`
}

export default function App() {
  const [sessions, setSessions] = useState([])
  const [activeId, setActiveId] = useState(null)
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const [streaming, setStreaming] = useState(false)
  const [persona, setPersona] = useState('default')
  const [stats, setStats] = useState(null)
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const bottomRef = useRef(null)
  const inputRef = useRef(null)

  const loadSessions = useCallback(async () => {
    const r = await fetch(`${API}/sessions`)
    const data = await r.json()
    setSessions(data)
  }, [])

  const loadStats = useCallback(async () => {
    const r = await fetch(`${API}/stats`)
    const data = await r.json()
    setStats(data)
  }, [])

  useEffect(() => {
    loadSessions()
    loadStats()
    const t = setInterval(loadStats, 10000)
    return () => clearInterval(t)
  }, [loadSessions, loadStats])

  const selectSession = async (id) => {
    setActiveId(id)
    const r = await fetch(`${API}/sessions/${id}/messages`)
    const data = await r.json()
    setMessages(data)
    setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: 'smooth' }), 100)
  }

  const newSession = async () => {
    const r = await fetch(`${API}/sessions`, { method: 'POST' })
    const data = await r.json()
    setSessions(prev => [{ id: data.id, title: 'New Chat', created: data.created, messageCount: 0 }, ...prev])
    setActiveId(data.id)
    setMessages([])
    inputRef.current?.focus()
  }

  const deleteSession = async (id, e) => {
    e.stopPropagation()
    await fetch(`${API}/sessions/${id}`, { method: 'DELETE' })
    setSessions(prev => prev.filter(s => s.id !== id))
    if (activeId === id) { setActiveId(null); setMessages([]) }
    loadStats()
  }

  const exportSession = (id, e) => {
    e.stopPropagation()
    window.open(`${API}/sessions/${id}/export`, '_blank')
  }

  const sendMessage = async () => {
    const text = input.trim()
    if (!text || streaming || !activeId) return

    const userMsg = { role: 'user', content: text, ts: Date.now() }
    setMessages(prev => [...prev, userMsg])
    setInput('')
    setStreaming(true)

    const assistantMsg = { role: 'assistant', content: '', ts: Date.now(), streaming: true }
    setMessages(prev => [...prev, assistantMsg])

    try {
      const r = await fetch(`${API}/sessions/${activeId}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text, persona }),
      })

      const reader = r.body.getReader()
      const decoder = new TextDecoder()
      let buffer = ''

      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        buffer += decoder.decode(value, { stream: true })
        const lines = buffer.split('\n')
        buffer = lines.pop()
        for (const line of lines) {
          if (!line.startsWith('data: ')) continue
          const evt = JSON.parse(line.slice(6))
          if (evt.type === 'delta') {
            setMessages(prev => {
              const copy = [...prev]
              const last = { ...copy[copy.length - 1] }
              last.content += evt.text
              copy[copy.length - 1] = last
              return copy
            })
          }
          if (evt.type === 'done') {
            setMessages(prev => {
              const copy = [...prev]
              const last = { ...copy[copy.length - 1], streaming: false }
              copy[copy.length - 1] = last
              return copy
            })
            loadSessions()
            loadStats()
          }
        }
      }
    } catch (err) {
      setMessages(prev => {
        const copy = [...prev]
        const last = { ...copy[copy.length - 1], content: '⚠ Connection error. Is the backend running?', streaming: false, error: true }
        copy[copy.length - 1] = last
        return copy
      })
    }
    setStreaming(false)
  }

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const activePersona = PERSONAS.find(p => p.id === persona)

  return (
    <div className="layout">
      {/* Sidebar */}
      <aside className={`sidebar ${sidebarOpen ? 'open' : 'closed'}`}>
        <div className="sidebar-header">
          <div className="logo">
            <span className="logo-icon">⬡</span>
            <span className="logo-text">NeuralChat</span>
          </div>
          <button className="icon-btn" onClick={() => setSidebarOpen(v => !v)} title="Toggle sidebar">
            {sidebarOpen ? '◀' : '▶'}
          </button>
        </div>

        {sidebarOpen && (
          <>
            <button className="new-chat-btn" onClick={newSession}>
              <span>+</span> New Chat
            </button>

            <div className="sessions-label">Recent</div>
            <div className="sessions-list">
              {sessions.length === 0 && (
                <div className="empty-sessions">No chats yet</div>
              )}
              {sessions.map(s => (
                <div
                  key={s.id}
                  className={`session-item ${activeId === s.id ? 'active' : ''}`}
                  onClick={() => selectSession(s.id)}
                >
                  <div className="session-title">{s.title}</div>
                  <div className="session-meta">{s.messageCount} msgs</div>
                  <div className="session-actions">
                    <button className="tiny-btn" onClick={e => exportSession(s.id, e)} title="Export">↓</button>
                    <button className="tiny-btn danger" onClick={e => deleteSession(s.id, e)} title="Delete">×</button>
                  </div>
                </div>
              ))}
            </div>

            {stats && (
              <div className="stats-panel">
                <div className="stat-row">
                  <span className="stat-label">Sessions</span>
                  <span className="stat-val">{stats.totalSessions}</span>
                </div>
                <div className="stat-row">
                  <span className="stat-label">Messages</span>
                  <span className="stat-val">{stats.totalMessages}</span>
                </div>
                <div className="stat-row">
                  <span className="stat-label">Uptime</span>
                  <span className="stat-val">{formatUptime(stats.uptime)}</span>
                </div>
              </div>
            )}
          </>
        )}
      </aside>

      {/* Main */}
      <main className="main">
        {/* Header */}
        <header className="topbar">
          <div className="topbar-left">
            {!sidebarOpen && (
              <button className="icon-btn" onClick={() => setSidebarOpen(true)}>▶</button>
            )}
            <div className="chat-title">
              {activeId
                ? sessions.find(s => s.id === activeId)?.title || 'Chat'
                : 'Select or start a chat'}
            </div>
          </div>
          <div className="persona-picker">
            {PERSONAS.map(p => (
              <button
                key={p.id}
                className={`persona-btn ${persona === p.id ? 'active' : ''}`}
                style={{ '--c': p.color }}
                onClick={() => setPersona(p.id)}
                title={p.label}
              >
                <span>{p.icon}</span>
                <span className="persona-label">{p.label}</span>
              </button>
            ))}
          </div>
        </header>

        {/* Messages */}
        <div className="messages-area">
          {!activeId && (
            <div className="welcome">
              <div className="welcome-icon">⬡</div>
              <h1>NeuralChat</h1>
              <p>A real-time AI chat with streaming, personas, and session history.</p>
              <button className="start-btn" onClick={newSession}>Start a new chat →</button>
            </div>
          )}

          {activeId && messages.length === 0 && !streaming && (
            <div className="welcome">
              <div className="welcome-icon" style={{ color: activePersona.color }}>{activePersona.icon}</div>
              <h2>{activePersona.label} mode</h2>
              <p>Send your first message to begin.</p>
            </div>
          )}

          {messages.map((msg, i) => (
            <div key={i} className={`message ${msg.role} ${msg.error ? 'error' : ''}`}>
              <div className="msg-avatar" style={msg.role === 'assistant' ? { color: activePersona.color } : {}}>
                {msg.role === 'user' ? '○' : activePersona.icon}
              </div>
              <div className="msg-body">
                <div className="msg-content">
                  {msg.content || (msg.streaming ? '' : '…')}
                  {msg.streaming && <span className="cursor" />}
                </div>
                <div className="msg-time">{formatTime(msg.ts)}</div>
              </div>
            </div>
          ))}
          <div ref={bottomRef} />
        </div>

        {/* Input */}
        <div className="input-area">
          {!activeId && (
            <div className="input-overlay">Start a chat first</div>
          )}
          <div className="input-row">
            <textarea
              ref={inputRef}
              className="chat-input"
              placeholder={activeId ? `Message ${activePersona.label}…` : 'Select a chat to begin'}
              value={input}
              disabled={!activeId || streaming}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage() }
              }}
              rows={1}
            />
            <button
              className={`send-btn ${streaming ? 'loading' : ''}`}
              onClick={sendMessage}
              disabled={!activeId || !input.trim() || streaming}
            >
              {streaming ? '◌' : '↑'}
            </button>
          </div>
          <div className="input-hint">Enter to send · Shift+Enter for newline</div>
        </div>
      </main>
    </div>
  )
}
