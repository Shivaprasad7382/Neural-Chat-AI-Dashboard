import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import Anthropic from '@anthropic-ai/sdk';
import { v4 as uuidv4 } from 'uuid';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;
const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

app.use(cors());
app.use(express.json());

// In-memory store: { [sessionId]: { messages: [], created, title } }
const sessions = {};

function getOrCreateSession(sessionId) {
  if (!sessions[sessionId]) {
    sessions[sessionId] = { messages: [], created: Date.now(), title: 'New Chat' };
  }
  return sessions[sessionId];
}

// GET /sessions — list all sessions
app.get('/sessions', (req, res) => {
  const list = Object.entries(sessions).map(([id, s]) => ({
    id,
    title: s.title,
    created: s.created,
    messageCount: s.messages.length,
  }));
  res.json(list.sort((a, b) => b.created - a.created));
});

// POST /sessions — create new session
app.post('/sessions', (req, res) => {
  const id = uuidv4();
  sessions[id] = { messages: [], created: Date.now(), title: 'New Chat' };
  res.json({ id, ...sessions[id] });
});

// DELETE /sessions/:id
app.delete('/sessions/:id', (req, res) => {
  delete sessions[req.params.id];
  res.json({ ok: true });
});

// GET /sessions/:id/messages
app.get('/sessions/:id/messages', (req, res) => {
  const session = sessions[req.params.id];
  if (!session) return res.status(404).json({ error: 'Session not found' });
  res.json(session.messages);
});

// POST /sessions/:id/chat — streaming chat
app.post('/sessions/:id/chat', async (req, res) => {
  const { message, persona } = req.body;
  if (!message) return res.status(400).json({ error: 'Message required' });

  const session = getOrCreateSession(req.params.id);

  // Auto-title on first message
  if (session.messages.length === 0) {
    session.title = message.slice(0, 40) + (message.length > 40 ? '…' : '');
  }

  session.messages.push({ role: 'user', content: message, ts: Date.now() });

  const systemPrompts = {
    default: 'You are a helpful, concise assistant. Be direct and clear.',
    creative: 'You are a wildly creative AI bursting with ideas, metaphors, and imaginative thinking. Be vivid and inspiring.',
    analyst: 'You are a sharp data analyst. Break down problems with logic, bullet points, and structured reasoning.',
    mentor: 'You are a patient, wise mentor. Guide the user with encouragement, questions, and thoughtful advice.',
  };

  const systemPrompt = systemPrompts[persona] || systemPrompts.default;

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  let fullText = '';

  try {
    const stream = await client.messages.stream({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1024,
      system: systemPrompt,
      messages: session.messages.map(m => ({ role: m.role, content: m.content })),
    });

    for await (const event of stream) {
      if (event.type === 'content_block_delta' && event.delta?.type === 'text_delta') {
        fullText += event.delta.text;
        res.write(`data: ${JSON.stringify({ type: 'delta', text: event.delta.text })}\n\n`);
      }
    }

    session.messages.push({ role: 'assistant', content: fullText, ts: Date.now() });
    res.write(`data: ${JSON.stringify({ type: 'done', sessionTitle: session.title })}\n\n`);
    res.end();
  } catch (err) {
    console.error(err);
    res.write(`data: ${JSON.stringify({ type: 'error', message: err.message })}\n\n`);
    res.end();
  }
});

// GET /sessions/:id/export — export session as JSON
app.get('/sessions/:id/export', (req, res) => {
  const session = sessions[req.params.id];
  if (!session) return res.status(404).json({ error: 'Not found' });
  res.setHeader('Content-Disposition', `attachment; filename="chat-${req.params.id.slice(0,8)}.json"`);
  res.json({ ...session, exportedAt: new Date().toISOString() });
});

// GET /stats
app.get('/stats', (req, res) => {
  const totalSessions = Object.keys(sessions).length;
  const totalMessages = Object.values(sessions).reduce((acc, s) => acc + s.messages.length, 0);
  res.json({ totalSessions, totalMessages, uptime: process.uptime() });
});

app.listen(PORT, () => console.log(`\n🚀 Server running at http://localhost:${PORT}\n`));
