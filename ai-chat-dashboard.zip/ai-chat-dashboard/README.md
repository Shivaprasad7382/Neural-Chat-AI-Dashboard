# ⬡ NeuralChat — Real-time AI Chat Dashboard

A fullstack AI chat application with:
- **Streaming responses** via Server-Sent Events (SSE)
- **4 AI Personas** (Assistant, Creative, Analyst, Mentor)
- **Session management** with history, export, and delete
- **Live stats** panel (sessions, messages, uptime)
- **Dark editorial UI** with DM Mono + Syne fonts

---

## Stack

| Layer | Tech |
|-------|------|
| Frontend | React + Vite |
| Backend | Node.js + Express |
| AI | Anthropic Claude (claude-sonnet-4) |
| Streaming | Server-Sent Events (SSE) |

---

## Getting Started

### 1. Backend

```bash
cd backend
npm install
cp .env.example .env
# Edit .env and add your ANTHROPIC_API_KEY
npm run dev
```

Server runs at **http://localhost:3001**

### 2. Frontend

```bash
cd frontend
npm install
npm run dev
```

App runs at **http://localhost:5173**

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | /sessions | List all sessions |
| POST | /sessions | Create new session |
| DELETE | /sessions/:id | Delete a session |
| GET | /sessions/:id/messages | Get messages for session |
| POST | /sessions/:id/chat | Send message (streams SSE) |
| GET | /sessions/:id/export | Export session as JSON |
| GET | /stats | Server stats |

---

## Features

- **Streaming**: Responses stream token-by-token using SSE — no waiting for full response
- **Personas**: Switch AI personality mid-conversation
  - `◈ Assistant` — Helpful and direct
  - `✦ Creative` — Imaginative and vivid
  - `◉ Analyst` — Structured and logical
  - `◎ Mentor` — Encouraging and reflective
- **Session history**: All chats persisted in memory during server session
- **Export**: Download any chat as JSON
- **Drag-resize sidebar**: Toggle sidebar open/closed

---

## Project Structure

```
ai-chat-dashboard/
├── backend/
│   ├── server.js        # Express + SSE + Anthropic SDK
│   ├── package.json
│   └── .env.example
└── frontend/
    ├── src/
    │   ├── App.jsx      # Main React component
    │   ├── App.css      # Dark editorial styles
    │   ├── index.css    # Global CSS variables
    │   └── main.jsx     # Entry point
    ├── index.html
    ├── vite.config.js
    └── package.json
```

---

## Extending

Ideas to build on top of this:
- Add PostgreSQL / SQLite for persistent storage
- Add user authentication (JWT)
- Add file upload support (PDF summarization)
- Add voice input via Web Speech API
- Deploy backend to Railway, Render, or Fly.io
- Deploy frontend to Vercel or Netlify
